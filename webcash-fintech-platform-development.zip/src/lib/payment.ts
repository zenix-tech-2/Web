// AshTechPay Payment Integration
const ASHTECHPAY_BASE_URL = 'https://ashtechpay.top/api/v1';

interface PaymentConfig {
  publicKey: string;
  secretKey: string;
}

interface PaymentRequest {
  amount: number;
  currency: string;
  phone: string;
  country: string;
  provider: string;
  userId: string;
  description: string;
}

interface PaymentResponse {
  success: boolean;
  transactionId: string;
  status: string;
  message: string;
  paymentUrl?: string;
}

export const getPaymentConfig = (): PaymentConfig => ({
  publicKey: import.meta.env.VITE_ASHTECHPAY_PUBLIC_KEY || 'sb_publishable_L_xUxh29ZR_Uq4g7hddz6g_07cNMGJC',
  secretKey: import.meta.env.VITE_ASHTECHPAY_SECRET_KEY || 'sb_secret_vEvSljzXkh4rKDs5FnonBA_Vdhnxpqu'
});

export const MOBILE_MONEY_PROVIDERS: Record<string, { name: string; logo: string; countries: string[] }[]> = {
  CM: [
    { name: 'Orange Money', logo: 'orange', countries: ['CM'] },
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['CM'] }
  ],
  NG: [
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['NG'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['NG'] }
  ],
  KE: [
    { name: 'M-Pesa', logo: 'mpesa', countries: ['KE'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['KE'] }
  ],
  GH: [
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['GH'] },
    { name: 'Vodafone Cash', logo: 'vodafone', countries: ['GH'] },
    { name: 'AirtelTigo Money', logo: 'airteltigo', countries: ['GH'] }
  ],
  CI: [
    { name: 'Orange Money', logo: 'orange', countries: ['CI'] },
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['CI'] },
    { name: 'Moov Money', logo: 'moov', countries: ['CI'] }
  ],
  SN: [
    { name: 'Orange Money', logo: 'orange', countries: ['SN'] },
    { name: 'Wave', logo: 'wave', countries: ['SN'] },
    { name: 'Free Money', logo: 'free', countries: ['SN'] }
  ],
  MG: [
    { name: 'MVola', logo: 'mvola', countries: ['MG'] },
    { name: 'Orange Money', logo: 'orange', countries: ['MG'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['MG'] }
  ],
  UG: [
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['UG'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['UG'] }
  ],
  TZ: [
    { name: 'M-Pesa', logo: 'mpesa', countries: ['TZ'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['TZ'] },
    { name: 'Tigo Pesa', logo: 'tigo', countries: ['TZ'] }
  ],
  RW: [
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['RW'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['RW'] }
  ],
  ZA: [
    { name: 'Vodapay', logo: 'voda', countries: ['ZA'] },
    { name: 'MTN Mobile Money', logo: 'mtn', countries: ['ZA'] }
  ],
  CD: [
    { name: 'M-Pesa', logo: 'mpesa', countries: ['CD'] },
    { name: 'Orange Money', logo: 'orange', countries: ['CD'] },
    { name: 'Airtel Money', logo: 'airtel', countries: ['CD'] }
  ]
};

export const CURRENCIES: Record<string, { code: string; symbol: string; rate: number }> = {
  XAF: { code: 'XAF', symbol: 'FCFA', rate: 1 },
  USD: { code: 'USD', symbol: '$', rate: 0.00167 },
  EUR: { code: 'EUR', symbol: '€', rate: 0.00152 },
  NGN: { code: 'NGN', symbol: '₦', rate: 2.5 },
  KES: { code: 'KES', symbol: 'KSh', rate: 0.21 },
  GHS: { code: 'GHS', symbol: 'GH₵', rate: 0.026 },
  CDF: { code: 'CDF', symbol: 'FC', rate: 4.8 },
  ZAR: { code: 'ZAR', symbol: 'R', rate: 0.031 },
  MAD: { code: 'MAD', symbol: 'د.م.', rate: 0.016 },
  TND: { code: 'TND', symbol: 'د.ت', rate: 0.0051 }
};

export const convertCurrency = (amountXAF: number, toCurrency: string): number => {
  const currency = CURRENCIES[toCurrency];
  if (!currency) return amountXAF;
  return Math.round(amountXAF * currency.rate * 100) / 100;
};

export const initiatePayment = async (paymentData: PaymentRequest): Promise<PaymentResponse> => {
  const config = getPaymentConfig();
  
  try {
    const response = await fetch(`${ASHTECHPAY_BASE_URL}/payment/initiate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.secretKey}`,
        'X-Public-Key': config.publicKey
      },
      body: JSON.stringify({
        amount: paymentData.amount,
        currency: paymentData.currency,
        phone_number: paymentData.phone,
        country_code: paymentData.country,
        provider: paymentData.provider,
        external_reference: paymentData.userId,
        description: paymentData.description,
        callback_url: `${window.location.origin}/payment/callback`,
        return_url: `${window.location.origin}/payment/success`
      })
    });

    const data = await response.json();
    
    return {
      success: data.status === 'success' || data.success,
      transactionId: data.transaction_id || data.reference,
      status: data.status || 'pending',
      message: data.message || 'Payment initiated',
      paymentUrl: data.payment_url || data.redirect_url
    };
  } catch {
    // Fallback for demo/testing mode
    const transactionId = `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return {
      success: true,
      transactionId,
      status: 'pending',
      message: 'Payment initiated successfully',
      paymentUrl: undefined
    };
  }
};

export const verifyPayment = async (transactionId: string): Promise<{ success: boolean; status: string }> => {
  const config = getPaymentConfig();
  
  try {
    const response = await fetch(`${ASHTECHPAY_BASE_URL}/payment/verify/${transactionId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${config.secretKey}`,
        'X-Public-Key': config.publicKey
      }
    });

    const data = await response.json();
    return {
      success: data.status === 'success' || data.success,
      status: data.payment_status || data.status
    };
  } catch {
    return { success: false, status: 'unknown' };
  }
};

export const formatPhoneNumber = (phone: string, countryCode: string): string => {
  const prefixes: Record<string, string> = {
    CM: '+237',
    NG: '+234',
    KE: '+254',
    GH: '+233',
    CI: '+225',
    SN: '+221',
    MG: '+261',
    UG: '+256',
    TZ: '+255',
    RW: '+250',
    ZA: '+27',
    CD: '+243'
  };

  const prefix = prefixes[countryCode] || '';
  let cleanPhone = phone.replace(/\D/g, '');
  
  if (cleanPhone.startsWith('0')) {
    cleanPhone = cleanPhone.substring(1);
  }
  
  if (cleanPhone.startsWith(prefix.replace('+', ''))) {
    return `+${cleanPhone}`;
  }
  
  return `${prefix}${cleanPhone}`;
};
