import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://whglmhqnestemuhvtpsm.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoZ2xtaHFuZXN0ZW11aHZ0cHNtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE4ODEzNjgsImV4cCI6MjA5NzQ1NzM2OH0.3dV2VspSSmxo9j4jIrcEXZIW6YjhBKTqOVTORP_LmGQ';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});

export const getServiceClient = () => {
  const serviceKey = import.meta.env.VITE_SUPABASE_SERVICE_KEY;
  if (!serviceKey) return null;
  return createClient(supabaseUrl, serviceKey);
};
